# Sources

- Berkeley LAPACK seminar (via BANANA mailing list)
- Stanford LA/OPT seminar (via BANANA mailing list)
- [Cornell SCAN seminar][1]
- [Cornell CAM colloquium][2]
- [MIT applied math colloquium][3]
- [NYU numerical analysis seminar][4]
- [UCLA applied math colloquium][5]
- [Georgia Tech CSE talks][6]
- [NCSU applied math colloquium][7]
- [NCSU numerical analysis seminar][8]
- [Temple applied math/scientific computing seminar][9]
- [Virginia Tech math colloquium][10]
- [Oxford computational math seminar][11]
- [Manchester numerical analysis and scientific computing][12]

[1]: http://www.math.cornell.edu/~scan
[2]: http://www.cam.cornell.edu/news/colloquium.cfm
[3]: http://www-math.mit.edu/amc/fall14
[4]: http://www.cs.nyu.edu/webaps/nasc_seminars
[5]: http://papyrus.math.ucla.edu/seminars/show_quarter.php?t=&type=Applied%20Colloquium&id=&tba=
[6]: http://www.cse.gatech.edu/taxonomy/term/248/all
[7]: https://www.math.ncsu.edu/events/AppliedMC.php
[8]: https://www.math.ncsu.edu/events/NAS.php
[9]: https://math.temple.edu/events/seminars/applied/
[10]: http://www.math.vt.edu/people/plinnell/Colloq14/index.php
[11]: https://www0.maths.ox.ac.uk/groups/numerical-analysis/seminars
[12]: http://www.maths.manchester.ac.uk/our-research/events/seminars/numerical-analysis-and-scientific-computing/
