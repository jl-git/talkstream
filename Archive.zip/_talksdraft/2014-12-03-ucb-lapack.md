---
title: 
speaker: Dan Spielman
speaker-url: 
affil: Yale University
date: 2014-12-03 12:10:00
talk-url: 
series: ucb-lapack
---
