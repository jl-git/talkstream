---
title: 
speaker: Ming Gu
speaker-url: 
affil: UC Berkeley
date: 2014-11-26 12:10:00
talk-url: 
series: ucb-lapack
---
