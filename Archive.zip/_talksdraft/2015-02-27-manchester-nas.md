---
title: TBC
speaker: David Titley-Peloquin
speaker-url: http://www.cerfacs.fr/~titleypelo/
affil: CERFACS
date: 2015-02-27 15:00:00
talk-url: http://www.maths.manchester.ac.uk/our-research/events/seminars/numerical-analysis-and-scientific-computing/tbc-3.htm
series: manchester-nas
---
