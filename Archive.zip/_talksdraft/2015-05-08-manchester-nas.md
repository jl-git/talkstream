---
title: TBC
speaker: Thomas Richter
speaker-url: http://www.numerik.uni-hd.de/~richter/
