---
title: TBC
speaker: Alexey Chernov
speaker-url: http://www.reading.ac.uk/maths-and-stats/about/Staff/a-chernov.aspx
affil: University of Reading
date: 2014-12-05 15:00:00
talk-url: http://www.maths.manchester.ac.uk/our-research/events/seminars/numerical-analysis-and-scientific-computing/tbc.htm
series: manchester-nas
---
