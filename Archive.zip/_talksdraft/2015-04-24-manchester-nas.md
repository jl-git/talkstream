---
title: TBC
speaker: Melina Freitag
speaker-url: http://people.bath.ac.uk/mamamf/
affil: University of Bath
date: 2015-04-24 15:00:00
talk-url: http://www.maths.manchester.ac.uk/our-research/events/seminars/numerical-analysis-and-scientific-computing/tbc-6.htm
series: manchester-nas
---
