---
title: Computational Tools for PDEs with Random Coefficients
speaker: Elisabeth Ullmann
speaker-url: http://people.bath.ac.uk/eu204/
affil: University of Hamburg
date: 2014-11-13 15:00:00
talk-url: http://www.maths.manchester.ac.uk/our-research/events/seminars/numerical-analysis-and-scientific-computing/computational-tools-for-pdes-with-random-coefficients.htm
series: manchester-nas
---
