---
title: TBC
speaker: Andrew Thompson
speaker-url: http://www.math.duke.edu/~thompson/
affil: University of Oxford
date: 2015-02-13 15:00:00
talk-url: http://www.maths.manchester.ac.uk/our-research/events/seminars/numerical-analysis-and-scientific-computing/tbc-2.htm
series: manchester-nas
---
