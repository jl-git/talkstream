---
title: TBC
speaker: Agnieszka Miedlar
speaker-url: https://www.math.tu-berlin.de/fachgebiete_ag_modnumdiff/fg_numerische_mathematik/v-menue/mitarbeiter/agnieszka_miedlar/home/
affil: TU Berlin
date: 2015-11-13 15:00:00
talk-url: http://www.maths.manchester.ac.uk/our-research/events/seminars/numerical-analysis-and-scientific-computing/tbc-1.htm
series: manchester-nas
---
