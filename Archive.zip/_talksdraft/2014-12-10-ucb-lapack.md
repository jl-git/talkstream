---
title: 
speaker: Jianwei Xiao
speaker-url: 
affil: UC Berkeley
date: 2014-12-10 12:10:00
talk-url: 
series: ucb-lapack
---
