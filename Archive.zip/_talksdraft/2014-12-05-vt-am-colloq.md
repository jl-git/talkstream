---
title: 
speaker: Tim Chartier
speaker-url: http://academics.davidson.edu/math/chartier/
affil: Davidson College
date: 2014-12-05 16:00:00
talk-url: http://www.math.vt.edu/people/plinnell/Colloq14/dec05.php
series: vt-am-colloq
---
