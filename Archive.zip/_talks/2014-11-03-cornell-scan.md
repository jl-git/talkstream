---
title: "Tensor short course (II) : SVD-like Decompositions for Tensors"
speaker: Charlie Van Loan
speaker-url: http://www.cs.cornell.edu/cv/
affil: CS, Cornell
date: 2014-11-03 13:25:00
talk-url: http://www.math.cornell.edu/~scan/Tensor2.pdf
series: cornell-scan
---
