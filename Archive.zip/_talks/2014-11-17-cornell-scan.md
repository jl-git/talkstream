---
title: "Tensor short course (IV) : Low-Rank Approximation and the Curse of Dimensionality"
speaker: Charlie Van Loan
speaker-url: http://www.cs.cornell.edu/cv/
affil: CS, Cornell
date: 2014-11-17 13:25:00
talk-url: http://www.math.cornell.edu/~scan/Tensor4.pdf
series: cornell-scan
---
