---
title: "Tensor short course (I) : Connecting to Matrix Computations."
speaker: Charlie Van Loan
speaker-url: http://www.cs.cornell.edu/cv/
affil: CS, Cornell
date: 2014-10-27 13:25:00
talk-url: http://www.math.cornell.edu/~scan/Tensor1.pdf
series: cornell-scan
---
