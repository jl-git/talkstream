---
title: "Tensor short course (III) : Symmetry, Power Methods"
speaker: Charlie Van Loan
speaker-url: http://www.cs.cornell.edu/cv/
affil: CS, Cornell
date: 2014-11-10 13:25:00
talk-url: http://www.math.cornell.edu/~scan/Tensor3.pdf
series: cornell-scan
---
