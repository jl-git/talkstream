---
title: "The Many Names of (7,3,1)"
speaker: Bud Brown
speaker-url: http://www.math.vt.edu/people/ezbrown
affil: Virginia Tech
date: 2014-08-29 16:00:00
talk-url: http://www.math.vt.edu/people/plinnell/Colloq14/aug29.php
series: vt-am-colloq
---

Number theory, topology, graph colorings, projective geometry, combinatorial
designs, error-correcting codes, normed algebras, round-robin tournaments,
Hadamard matrices, sphere packings, finite fields, and orthogonal Latin squares
are all diverse and well-studied fields of mathematics. This talk is about
(7,3,1), an object that connects them all.
