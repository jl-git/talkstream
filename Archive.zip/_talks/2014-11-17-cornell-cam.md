---
title: "Bill Sears Club Seminar"
speaker: Gennady Samorodnitsky 
speaker-url: http://legacy.orie.cornell.edu/gennady/
affil: Cornell ORIE
date: 2014-11-17 13:25:00
talk-url: http://events.cornell.edu/event/cam_bill_sears_club_seminar_gennady_samorodnitsky_cornell_orie
series: cornell-cam
---

Seminar named in honor of Bill Sears, the first director of CAM.

