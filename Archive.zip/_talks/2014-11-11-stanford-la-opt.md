---
title:  Recent developments in optimization solvers
speaker: Erling Andersen
affil: CEO, MOSEK
date: 2014-11-11 16:15:00
series: stanford-la-opt
---

