---
title: "What is all the fuss concerning Common Core Math Standards - and why should you care?"
speaker: Grant Wiggins 
speaker-url: http://www.authenticeducation.org/whoweare/grant.lasso
affil: Authentic Education
date: 2014-10-17 13:25:00
talk-url: http://events.cornell.edu/event/cam_colloquium_grant_wiggins_authentic_education_-_what_is_all_the_fuss_concerning_common_core_math_standards_-_and_why_should_you_care
series: cornell-cam
---

As we know, the new national standards for math in K-12 education have gone
from being completely ho-hum and ignored to becoming a hot-button political
issue. What should we make of the controversy? What role, if any, should
college faculty play in terms of the Standards? Noted educational researcher,
consultant, and reformer Grant Wiggins will try to shed more light than heat on
this important topic.
