import os
from datetime import datetime
print str(datetime.now())
os.system("scrapy crawl courseWebPageCrawler")
