import os
from datetime import datetime
print str(datetime.now())
os.system("/usr/local/bin/scrapy crawl courseWebPageCrawler")
